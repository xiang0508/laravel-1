<?php echo e($slot); ?>

<?php /**PATH D:\UniServerZ\www\LaravelDemo-master\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>