*****商品內容*****

<hr />

    <?php echo e($post->content); ?>


<hr />
<?php /**PATH D:\UniServerZ\www\LaravelDemo-master\resources\views/posts/show.blade.php ENDPATH**/ ?>