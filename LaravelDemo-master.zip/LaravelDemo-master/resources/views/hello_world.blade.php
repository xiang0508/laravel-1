<!DOCTYPE html>

<html>

    <head>

        <meta charset="utf-8">

        <title>Hello world!!!</title>

    </head>

    <body>

      Hello World!!!中文也可以

    </body>

</html> 