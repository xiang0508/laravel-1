<title>**歡迎光臨生鮮商店**</title>
<H1 ><font color="blue" size="100px" style="background-color:powderblue">生鮮商品</font></H1>

<div >
<H1  style="background-color:powderblue;">組員:</H1><br>

<p  style="background-color:#ff6666;">張勇勝</p><br>

<p  style="background-color:#ccf5ff;">蔡子鎮</p><br>

<p style="background-color:#b3ff99;">方鴻祥</p><br>

<input name="Submit" type="button" id="Submit" onClick="javascript:history.back(1)" value="回上一頁" /></div>