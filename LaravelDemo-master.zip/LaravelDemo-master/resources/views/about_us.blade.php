@extends('layouts.app')

@section('content')

    <p>嗨！大家好！我們是{{$name}}</p>

@endsection