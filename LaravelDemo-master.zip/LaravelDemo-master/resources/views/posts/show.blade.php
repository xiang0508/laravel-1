<title>**歡迎光臨生鮮商店**</title>
<style>

</style>
<body style="background-color:green;">
<div >
<H1 >*****商品內容*****</H1>

<hr />

    {{ $post->content }}



<input name="Submit" type="button" id="Submit" onClick="javascript:history.back(1)" value="回上一頁" /></input><br>

</div>
</body>